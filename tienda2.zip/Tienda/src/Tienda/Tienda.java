package Tienda;

//import Tienda.Producto.Tipo;

public class Tienda {
	
	// -----------------------------------------------------------------
	 // Atributos
	 // -----------------------------------------------------------------
	
	private Producto producto1;
	
	private Producto producto2;
	
	private Producto producto3;
	
	private Producto producto4;
	
	private double dineroEnCaja;
	
	// -----------------------------------------------------------------
	 // Constructores
	 // -----------------------------------------------------------------
	
	/**
	 * Crea la tienda con sus 4 productos. <br>
	 * <b> post: </b> El dinero en caja fue inicializado en 0.<br>
	 * Los 4 productos fueron inicializados con los siguientes valores: <br>
	 * Producto 1 - Tipo: PAPELERIA, Nombre: Lápiz, Valor unitario: 550.0, Cantidad en bodega: 18,
	 * Cantidad mínima: 5, Imagen: lapiz.png. <br>
	 * Producto 2 - Tipo: DROGUERIA, Nombre: Aspirina, Valor unitario: 109.5, Cantidad en bodega:
	 * 25, Cantidad mínima: 8, Imagen: aspirina.png. <br>
	 * Producto 3 - Tipo: PAPELERIA, Nombre: Borrador, Valor unitario: 207.3, Cantidad en bodega:
	 * 30, Cantidad mínima: 10, Imagen: borrador.png. <br>
	 * Producto 4 - Tipo: SUPERMERCADO, Nombre: Pan, Valor unitario: 150.0, Cantidad en bodega:
	 * 15, Cantidad mínima: 20, Imagen: pan.png. <br>
	 */
	

	public Tienda(Producto producto1, Producto producto2, Producto producto3, 
			Producto producto4, double dineroEnCaja) {
		super();
		this.producto1 = producto1;
		this.producto2 = producto2;
		this.producto3 = producto3;
		this.producto4 = producto4;
		this.dineroEnCaja = dineroEnCaja;
	}

	public Producto getProducto1() {
		return producto1;
	}

	public Producto getProducto2() {
		return producto2;
	}

	public Producto getProducto3() {
		return producto3;
	}

	public Producto getProducto4() {
		return producto4;
	}

	public double getDineroEnCaja() {
		return dineroEnCaja;
	}

	
	public String toString() {
		return "TIENDA \n[producto1=" + producto1 + "\n producto2=" + producto2 + "\n producto3=" + producto3
				+ "\n producto4=" + producto4 + "]";
	}
	
	/**
	 * Retorna el producto con el nombre dado por parámetro.
	 * @param pNombre Nombre del producto buscado. pNombre != null && pNombre != "".
	 * @return Producto con el nombre dado por parámetro, null si no lo encuentra.
	 */

	public String darProducto(String buscar) {
        String buscado=null;

        if (buscar.equals(producto1.getNombre())) 
        		{
            buscado = producto1.mostrarTodo();
            
        } else if (buscar.equals(producto2.getNombre())) {
            buscado = producto2.mostrarTodo();
        } else if (buscar.equals(producto3.getNombre())) {
            buscado = producto3.mostrarTodo();
        } else if (buscar.equals(producto4.getNombre())) {
            buscado = producto4.mostrarTodo();
        }

        return buscado;
    }
	
	public double darPromedioVentas() {
		double promedio = (producto1.getCantidadUnidadesVendidas()+producto2.getCantidadUnidadesVendidas()+
				producto3.getCantidadUnidadesVendidas()+producto4.getCantidadUnidadesVendidas())/4;
		
		return promedio;
		
	}
	
	public Producto darProductoMasVendido() {
		Producto productoVendido = null;
		
		if ((producto1.getCantidadUnidadesVendidas()>producto2.getCantidadUnidadesVendidas())
				&&producto1.getCantidadUnidadesVendidas()>producto3.getCantidadUnidadesVendidas()
				&&producto1.getCantidadUnidadesVendidas()>producto4.getCantidadUnidadesVendidas()) {
			productoVendido= producto1;
		}
		if ((producto2.getCantidadUnidadesVendidas()>producto1.getCantidadUnidadesVendidas())
				&&producto2.getCantidadUnidadesVendidas()>producto3.getCantidadUnidadesVendidas()
				&&producto2.getCantidadUnidadesVendidas()>producto4.getCantidadUnidadesVendidas()) {
			productoVendido= producto2;
		}
		if ((producto3.getCantidadUnidadesVendidas()>producto2.getCantidadUnidadesVendidas())
				&&producto3.getCantidadUnidadesVendidas()>producto1.getCantidadUnidadesVendidas()
				&&producto3.getCantidadUnidadesVendidas()>producto4.getCantidadUnidadesVendidas()) {
			productoVendido= producto3;
		}
		if ((producto4.getCantidadUnidadesVendidas()>producto2.getCantidadUnidadesVendidas())
				&&producto4.getCantidadUnidadesVendidas()>producto3.getCantidadUnidadesVendidas()
				&&producto4.getCantidadUnidadesVendidas()>producto1.getCantidadUnidadesVendidas()) {
			productoVendido= producto4;
		}
		return productoVendido;
	}
	
	public Producto darProductoMenossVendido() {
		Producto productoVendido = null;
		
		if ((producto1.getCantidadUnidadesVendidas()<producto2.getCantidadUnidadesVendidas())
				&&producto1.getCantidadUnidadesVendidas()<producto3.getCantidadUnidadesVendidas()
				&&producto1.getCantidadUnidadesVendidas()<producto4.getCantidadUnidadesVendidas()) {
			productoVendido= producto1;
		}
		if ((producto2.getCantidadUnidadesVendidas()<producto1.getCantidadUnidadesVendidas())
				&&producto2.getCantidadUnidadesVendidas()<producto3.getCantidadUnidadesVendidas()
				&&producto2.getCantidadUnidadesVendidas()<producto4.getCantidadUnidadesVendidas()) {
			productoVendido= producto2;
		}
		if ((producto3.getCantidadUnidadesVendidas()<producto2.getCantidadUnidadesVendidas())
				&&producto3.getCantidadUnidadesVendidas()<producto1.getCantidadUnidadesVendidas()
				&&producto3.getCantidadUnidadesVendidas()<producto4.getCantidadUnidadesVendidas()) {
			productoVendido= producto3;
		}
		if ((producto4.getCantidadUnidadesVendidas()<producto2.getCantidadUnidadesVendidas())
				&&producto4.getCantidadUnidadesVendidas()<producto3.getCantidadUnidadesVendidas()
				&&producto4.getCantidadUnidadesVendidas()<producto1.getCantidadUnidadesVendidas()) {
			productoVendido= producto4;
		}
		return productoVendido;
	}
	/**
	 * Vende una cantidad de unidades de producto de la tienda, dado su nombre por parámetro.
	 * <br>
	 * <b>post: </b> Disminuyó la cantidad de unidades del producto dado y se actualizó el dinero
	 * de la caja.
	 * @param pNombreProducto Nombre del producto a vender. npNombreProducto != null &&
	 * pNombreProducto != "".
	 * @param pCantidad Cantidad de unidades del producto a vender. pCantidad > 0.
	 * @return Cantidad que fue efectivamente vendida.
	 */

	public int venderProducto(String buscar,int cantidadComprar) {
		
		if (buscar.equals(producto1.getNombre())) {
			cantidadComprar= producto1.vender(cantidadComprar);
			dineroEnCaja = dineroEnCaja+(cantidadComprar * producto1.calcularPrecioFinal());
			
			
		}else {
			if (buscar.equals(producto2.getNombre())) {
				cantidadComprar=producto2.vender(cantidadComprar);
				dineroEnCaja = dineroEnCaja+(cantidadComprar * producto2.calcularPrecioFinal());
				
		}else {
			if (buscar.equals(producto3.getNombre())) {
				cantidadComprar=producto3.vender(cantidadComprar);
				dineroEnCaja = dineroEnCaja+(cantidadComprar * producto3.calcularPrecioFinal());
				
			}else {
				if (buscar.equals(producto4.getNombre())) {
					cantidadComprar=producto4.vender(cantidadComprar);
					dineroEnCaja = dineroEnCaja+(cantidadComprar * producto4.calcularPrecioFinal());
					
			}else {
				cantidadComprar=0;
			}
			}
			}
		}
		return cantidadComprar;
	}
	public boolean abastecerProducto(String buscar,int cantidadIngresar) {
		boolean abastecer=false;
		if (buscar== producto1.getNombre()) {
			
			if(buscar.equals(producto1.getNombre())) {
				producto1.abastecer(cantidadIngresar);
				abastecer= true;
			}
			
		}else {
			if (buscar.equals(producto2.getNombre())) {
				
				if(producto2.puedeAbastecer()==true) {
					producto2.abastecer(cantidadIngresar);
					abastecer= true;
				}
		}else {
			if (buscar.equals(producto3.getNombre())) {
				if(producto3.puedeAbastecer()==true) {
					producto3.abastecer(cantidadIngresar);
					abastecer= true;
				}
			}else {
				if (buscar.equals(producto4.getNombre())) {
					if(producto4.puedeAbastecer()==true) {
						producto4.abastecer(cantidadIngresar);
						abastecer= true;
					}
			}
			}
			}
		}
		return abastecer;
			
	}
	
	/**
	 * Cambia el producto que tiene el nombre actual con los nuevos valores dados por parámetro.
	 * <br>
	 * <b>post: </b> El nombre, tipo, valor unitario, cantidad en bodega y cantidad mínima fueron
	 * cambiados con los valores dados por parámetro.
	 * @param pNombreActual Nombre actual del producto. pNombreActual != null &&
	 * pNombreActual != "".
	 * @param pNombreNuevo Nuevo nombre del producto. pNombreNuevo != null &&
	 * pNombreNuevo != "".
	 * @param pTipo Tipo del producto. pTipo != null.
	 * @param pValorUnitario Valor unitario del producto
	 * @param pCantidadBodega Cantidad en bodega del producto. pCantidadBodega >= 0.
	 * @param pCantidadMinima Cantidad mínima en bodega para hacer un pedido del producto.
	 * pCantidadMinima > 0.
	 * @param pRutaImagen Ruta de la imagen del producto. pRutaImagen != null && pRutaImagen
	 * != "".
	 * @return Retorna true si cambió la información del producto, false si ya existía un producto
	 * diferente con el nuevo nombre.
	 */
	public boolean cambiarProducto(String buscar,String nuevoNombre, Tipo nTipo,double nValorUnitario,
			int nCantidadBodega, int nCantidadMinima,String nRutaImagen) {
		
		boolean cambiar = false;
		if (buscar== producto1.getNombre()) {
			//cambiamos todo lo del producto 1 
			producto1.setNombre(nuevoNombre);
			producto1.setTipo(nTipo);
			producto1.setValorUnitario(nValorUnitario);
			producto1.setCantidadBodega(nCantidadBodega);
			producto1.setCantidadMinima(nCantidadMinima);
			producto1.setRutaImagen(nRutaImagen);
			cambiar = true;
		}else {
			if (buscar== producto2.getNombre()) {
				producto2.setNombre(nuevoNombre);
				producto2.setTipo(nTipo);
				producto2.setValorUnitario(nValorUnitario);
				producto2.setCantidadBodega(nCantidadBodega);
				producto2.setCantidadMinima(nCantidadMinima);
				producto2.setRutaImagen(nRutaImagen);
				cambiar = true;
		}else {
			if (buscar== producto3.getNombre()) {
				producto3.setNombre(nuevoNombre);
				producto3.setTipo(nTipo);
				producto3.setValorUnitario(nValorUnitario);
				producto3.setCantidadBodega(nCantidadBodega);
				producto3.setCantidadMinima(nCantidadMinima);
				producto3.setRutaImagen(nRutaImagen);
				cambiar = true;
			}else {
				if (buscar== producto4.getNombre()) {
				producto4.setNombre(nuevoNombre);
				producto4.setTipo(nTipo);
				producto4.setValorUnitario(nValorUnitario);
				producto4.setCantidadBodega(nCantidadBodega);
				producto4.setCantidadMinima(nCantidadMinima);
				producto4.setRutaImagen(nRutaImagen);
				cambiar = true;
			}
			}
			}
		}
		return cambiar;
		
	}
}
	
