package Tienda;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		//vamos a crear los 4 productos e inicializar todo
		Producto producto1 = new Producto("lapiz",Tipo.PAPELERIA,550.0,18,5,"lapiz.png");
		Producto producto2 = new Producto("aspirina",Tipo.DROGERIA,109.5,25,8,"aspirina.png");
		Producto producto3 = new Producto("borrador",Tipo.PAPELERIA,207.3,30,10,"borrador.png");
		Producto producto4 = new Producto("pan",Tipo.SUPERMERCADO,150.0,15,20,"pan.png");
		double dineroEnCaja=0;
		Tienda tienda1 = new Tienda(producto1,producto2, producto3, 
				 producto4, dineroEnCaja);
		
		Scanner scanner = new Scanner(System.in);
		int opc =0;
		while(opc==0) {
			//menu para ver q hhacer
			
			System.out.println("Aplicación de la tienda");
			System.out.println("Elige la opcion a realizar ");
			System.out.println("1.Ver todos los productos.\n2.Ver dinero en caja \n3.Buscar existencias del producto\n"
					+ "4.Vender productos \n5.Abastecer productos\n6.Cambiar productos \n 7.Salir");
			System.out.println("Opcion: ");
			opc = scanner.nextInt();
			switch(opc) {
			
			case 1:
				System.out.println(tienda1.toString());
				opc=0;
				break;
				
			case 2:System.out.println("El dinero en caja es: "+tienda1.getDineroEnCaja());
				opc=0;
				break;
			case 3:System.out.println("Escriba el producto a buscar: ");
				scanner.nextLine();
			
				String buscar = scanner.next().toLowerCase();					
				String productoB = tienda1.darProducto(buscar);
				if (productoB == null) {
					System.out.println("Producto no encontrado ");
				}else {
					System.out.println("El producto es: "+ productoB);
				}
					
					//no esta tomando el parametro proporcioanado y no hace comparacion
				opc=0;
				break;
			case 4:
				scanner.nextLine();
				System.out.println("Escriba el producto a vender: ");
				
				String vender= scanner.nextLine();
				
				if (vender !=null) {
					System.out.println("Escriba la cantidad de producto a vender: ");
					
					int cantidad = scanner.nextInt();
					
					int vendido= tienda1.venderProducto(vender, cantidad);
					
					if (vendido>0) {
						System.out.println("Se han vendido "+cantidad +" de "+vender);
					}else {
						System.out.println("No se ha podido vender ");
					}
				}else {
					System.out.println("Opcion no valida");
				}

				opc=0;
				break;
			case 5:
				scanner.nextLine();
				System.out.println("Escriba el producto a abastecer: ");
				String abastece= scanner.nextLine();
				if (abastece !=null) {
					System.out.println("Escriba la cantidad de producto a abastcer: ");
					
					int cantidad = scanner.nextInt();
					if(cantidad>0) {
						boolean abastecido= tienda1.abastecerProducto(abastece, cantidad);
						
						if (abastecido== true) {
							System.out.println("Se han abastecido "+ cantidad +" de "+abastece);
						}else {
							System.out.println("No se ha podido abastecer ");
						}
						
					}else {
						System.out.println("No se ha podido abastecer ");
					}
					
				}else {
					System.out.println("Opcion no valida");
				}
				opc=0;
				break;
			case 6:
					System.out.println("Escriba el producto a cambiar");
					String productoBuscar= scanner.nextLine();
					scanner.nextLine();
					System.out.println("Escriba el nombre del nuevo producto: ");
					String nuevoNombre = scanner.nextLine();
					scanner.nextLine();
					System.out.println("Escriba la cantidad del nuevo producto: ");
					int nCantidadBodega = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Escriba el tipo del nuevo producto: ");
					String nTipo = scanner.nextLine().toLowerCase();
					scanner.nextLine();
					Tipo nuevoTipo = null;
					if(nTipo.equals(Tipo.DROGERIA)) {
						
						nuevoTipo =Tipo.DROGERIA;
					}else if(nTipo.equals(Tipo.PAPELERIA)){
						nuevoTipo =Tipo.PAPELERIA;
					}else if(nTipo.equals(Tipo.SUPERMERCADO)){
						 nuevoTipo = Tipo.SUPERMERCADO;
					}
					
					System.out.println("Escriba el valor unitario del nuevo producto: ");
					double nValorUnitario = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Escriba la cantidad minima del nuevo producto: ");
					int nCantidadMinima = scanner.nextInt();
					scanner.nextLine();
					System.out.println("Escriba la ruta de imagen del nuevo producto: ");
					String nRutaImagen = scanner.nextLine();
					scanner.nextLine();
					
					System.out.println("¿Se ha realizado el cambio?"+tienda1.cambiarProducto(productoBuscar, nuevoNombre, nuevoTipo,
							nValorUnitario, nCantidadBodega, nCantidadMinima, nRutaImagen));
				opc=0;
				break;
			case 7:
				System.out.println("Cerrando ");
				opc=1;
				break;
			default: 	
				System.out.println("Opcion invalida");
				opc = 0;
				break;
			}
			
		}
		
		
		scanner.close();
		
		/*int opc = scanner.nextInt();
			
		String hola = scanner.nextLine();
		int comprar = producto1.veder(opc);;
		
		System.out.println("vendido: "+comprar + " de "+ nombre);
	*/
	}

}
