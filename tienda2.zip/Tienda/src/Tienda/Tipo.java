package Tienda;

public enum Tipo {
	PAPELERIA,
	SUPERMERCADO,
	DROGERIA;

}