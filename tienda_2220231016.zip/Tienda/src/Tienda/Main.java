package Tienda;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		//vamos a crear los 4 productos e inicializar todo
		Producto producto1 = new Producto("lapiz",Tipo.PAPELERIA,550.0,18,5,"lapiz.png");
		Producto producto2 = new Producto("Aspirina",Tipo.DROGERIA,109.5,25,8,"aspirina.png");
		Producto producto3 = new Producto("Borrador",Tipo.PAPELERIA,207.3,30,10,"borrador.png");
		Producto producto4 = new Producto("Pan",Tipo.SUPERMERCADO,150.0,15,20,"pan.png");
		double dineroEnCaja=0;
		Tienda tienda1 = new Tienda(producto1,producto2, producto3, 
				 producto4, dineroEnCaja);
		
		Scanner scanner = new Scanner(System.in);
		int opc =0;
		while(opc==0) {
			//menu para ver q hhacer
			
			System.out.println("Aplicación de la tienda");
			System.out.println("Elige la opcion a realizar ");
			System.out.println("1.Ver todos los productos.\n2.Ver dinero en caja \n3.Buscar producto\n"
					+ "4.Vender productos \n5.Abastecer productos\n6.Cambiar productos \n 7.Salir");
			System.out.println("Opcion: ");
			opc = scanner.nextInt();
			switch(opc) {
			
			case 1:
				System.out.println(tienda1.toString());
				opc=0;
				break;
				
			case 2:System.out.println("El dinero en caja es: "+tienda1.getDineroEnCaja());
				opc=0;
				break;
			case 3:System.out.println("Escriba el producto a buscar: ");
					scanner.nextLine();
					//no esta tomando el parametro proporcioanado y no hace comparacion
				opc=0;
				break;
			case 4:
				opc=0;
				break;
			case 5:
				opc=0;
				break;
			case 6:
				opc=0;
				break;
			case 7:
				System.out.println("Cerrando ");
				opc=1;
				break;
			default: 	
				System.out.println("Opcion invalida");
				opc = 0;
				break;
			}
			
		}
		
		
		scanner.close();
		
		/*int opc = scanner.nextInt();
			
		String hola = scanner.nextLine();
		int comprar = producto1.veder(opc);;
		
		System.out.println("vendido: "+comprar + " de "+ nombre);
	*/
	}

}
