package Tienda;

public class Producto {
	
	
	// -----------------------------------------------------------------
	 // Enumeraciones
	 // -----------------------------------------------------------------

	
	
	// -----------------------------------------------------------------
	 // Constantes
	 // -----------------------------------------------------------------
	
	public final static double IVA_PAPELERIA=0.16;
	
	public final static double IVA_SUPERMERCADO= 0.04;
	
	public final static double IVA_DROGERIA=0.12;
	
	// -----------------------------------------------------------------
	 // Atributos
	 // -----------------------------------------------------------------

	private String nombre;
	
	private Tipo tipo;
	
	private double valorUnitario;
	
	private int cantidadBodega;
	
	//Cantidad de unidades mínima que debe haber en bodega para poder hacer un pedido
	
	private int cantidadMinima;
	
	private int cantidadUnidadesVendidas;
	
	private String rutaImagen;
	
	// -----------------------------------------------------------------
	 // Constructores
	 // -----------------------------------------------------------------
	
	/**
	 * 
	 * @param nombre   Nombre del producto. pNombre != null && pNombre != ""
	 * @param tipo  Tipo del producto. pTipo != null.
	 * @param valorUnitario  o Valor unitario del producto. pValorUnitario >= 0
	 * @param cantidadBodega Cantidad inicial en la bodega. pCantidadBodega >= 0.
	 * @param cantidadMinima Cantidad mínima que debe haber en bodega. pCantidadMinima >= 0.
	 * idk esta @param cantidadUnidadesVendidas
	 * @param rutaImagen  Ruta de la imagen del producto. pRutaImagen != null &&pRutaImagen != "".
	 */
	

	public String getNombre() {
		return nombre;
	}

	
	public Producto(String nombre, Tipo tipo, double valorUnitario, int cantidadBodega, int cantidadMinima,
			String rutaImagen) {
		super();
		this.nombre = nombre;
		this.tipo = tipo;
		this.valorUnitario = valorUnitario;
		this.cantidadBodega = cantidadBodega;
		this.cantidadMinima = cantidadMinima;
		this.rutaImagen = rutaImagen;
	}


	public Tipo getTipo() {
		return tipo;
	}

	public double getValorUnitario() {
		return valorUnitario;
	}

	public int getCantidadBodega() {
		return cantidadBodega;
	}

	public int getCantidadMinima() {
		return cantidadMinima;
	}

	public int getCantidadUnidadesVendidas() {
		return cantidadUnidadesVendidas;
	}

	public String getRutaImagen() {
		return rutaImagen;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public void setValorUnitario(double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}

	public void setCantidadBodega(int cantidadBodega) {
		this.cantidadBodega = cantidadBodega;
	}

	public void setCantidadMinima(int cantidadMinima) {
		this.cantidadMinima = cantidadMinima;
	}

	public void setCantidadUnidadesVendidas(int cantidadUnidadesVendidas) {
		this.cantidadUnidadesVendidas = cantidadUnidadesVendidas;
	}

	public void setRutaImagen(String rutaImagen) {
		this.rutaImagen = rutaImagen;
	}

	/**
	 * Calcula el valor final del producto, incluyendo los impuestos.
	 * @return Precio de venta de una unidad incluyendo el IVA.
	 */
	public double calcularPrecioFinal() {
		
		double precioFinal=0;
		
		if (tipo == Tipo.DROGERIA) {
			precioFinal= valorUnitario +(valorUnitario* IVA_DROGERIA);
			
		}
		if(tipo == Tipo.PAPELERIA) {
			precioFinal = valorUnitario +(valorUnitario* IVA_PAPELERIA);
		}
		if (tipo == Tipo.SUPERMERCADO) {
			precioFinal = valorUnitario +(valorUnitario* IVA_SUPERMERCADO);
		}
		
		return precioFinal;
	}
	
	public int vender(int cantidadComprar) {
		//cantiadad a comprar es lo que ingresa el ususrio 
		
		if ((cantidadComprar<=cantidadBodega) &&(cantidadBodega-cantidadComprar>=0)) {
			
			cantidadBodega =cantidadBodega-cantidadComprar;
			
			cantidadUnidadesVendidas=cantidadUnidadesVendidas+cantidadComprar;
			//System.out.println("vendido: "+cantidadComprar + " de "+ nombre);
			
		}
		return cantidadComprar;
	}
	 /**
	 * Abastece la cantidad de unidades dada por parámetro. <br>
	 * <b>post: </b> Aumenta la cantidad de unidades en bodega del producto.
	 * @param pCantidad Cantidad de unidades para abastecer. pCantidad >= 0.
	 */

	public void abastecer(int cantidadIngresar) {
		
		if (cantidadIngresar>=0) {
			cantidadBodega=cantidadBodega+cantidadIngresar;
			System.out.println("Se han añadido"+cantidadIngresar+" a la bodega ");
		}else {
			System.out.println("No se puede abastecer");
		}

	}
	
	 /**
	 * Indica si se puede abastecer las unidades del producto.
	 * @return True si la cantidad en la bodega es menor que la mínima, false en caso contrario.
	 */
	public boolean puedeAbastecer() {
		boolean puede;
		
		if (cantidadBodega<cantidadMinima) {
			puede = true;
			
		}else {
			puede=false;
		}
		return puede;
	}


	


	public String toString() {
		return "[nombre=" + nombre + ", tipo=" + tipo + ", valorUnitario=" + valorUnitario + ", rutaImagen="
				+ rutaImagen + "]";
	}
	
	
	
}
